class s extends Error{constructor(r){super(r),this.name="ElementPlusError"}}function o(e,r){throw new s(`[${e}] ${r}`)}function t(e,r){}export{t as d,o as t};

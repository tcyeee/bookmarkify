import{a as o}from"./bootstrap-Bdg0N8g_.js";const e=i=>o?window.requestAnimationFrame(i):setTimeout(i,16),a=i=>o?window.cancelAnimationFrame(i):clearTimeout(i);export{a as c,e as r};

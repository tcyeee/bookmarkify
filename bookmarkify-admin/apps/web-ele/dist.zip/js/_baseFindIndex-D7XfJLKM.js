function u(n,i,d,t){for(var l=n.length,e=d+(t?1:-1);t?e--:++e<l;)if(i(n[e],e,n))return e;return-1}export{u as b};

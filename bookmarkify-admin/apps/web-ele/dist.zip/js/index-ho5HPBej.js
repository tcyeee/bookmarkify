const _="--vben-content-height",E="--vben-content-width",n="--vben-header-height",t="--vben-footer-height",A="__vben_main_content",T="vben";export{_ as C,T as D,A as E,E as a,n as b,t as c};

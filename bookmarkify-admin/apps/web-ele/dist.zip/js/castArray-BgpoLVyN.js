import{b as a}from"./bootstrap-8icln2VM.js";function e(){if(!arguments.length)return[];var r=arguments[0];return a(r)?r:[r]}export{e as c};

import{s,o as t,i as e}from"./index-B60bgFpf.js";import{g as o,h as a}from"./bootstrap-8icln2VM.js";function m(i,r){return s(t(i,r,e),i+"")}function c(i){return o(i)&&a(i)}export{m as b,c as i};

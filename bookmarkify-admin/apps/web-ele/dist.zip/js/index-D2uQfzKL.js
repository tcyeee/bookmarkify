import{w as r,u as t}from"../jse/index-index-CGP7zSOX.js";const i=({from:a,replacement:o,scope:s,version:m,ref:p,type:c="API"},e)=>{r(()=>t(e),u=>{},{immediate:!0})};export{i as u};

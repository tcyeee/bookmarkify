import{s,o as t,i as e}from"./index-CZZCLOHg.js";import{g as o,h as a}from"./bootstrap-Bdg0N8g_.js";function m(i,r){return s(t(i,r,e),i+"")}function c(i){return o(i)&&a(i)}export{m as b,c as i};
